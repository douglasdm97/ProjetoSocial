angular.module('starter.services', [])

.factory('Chats', function() {
});
