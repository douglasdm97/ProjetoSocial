
controllers.
controller('NoAuthController', function($scope, $state, $ionicLoading, $ionicModal, $ionicPopup) {





});